=== Japanese font for TinyMCE ===
Contributors: raspi0124
Tags: TinyMCE,fonts,font,Japanese,JapaneseFont
Requires at least: 4.7
Tested up to: 4.8-alpha-40040
Stable tag: Beta
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add Japanese font to TinyMCE Advanced plugin's font family selections.

== Description ==
Add Japanese font to TinyMCE Advanced plugin's font family selections.<br>
Font to be added；<br>
<a href="http://hp.vector.co.jp/authors/VA039499/#hui">ふい字</a><br>
<a href="https://www.google.com/get/noto/#sans-jpan">Noto Sans Japanese</a><br>
<a href="http://jikasei.me/font/rounded-mplus/">自家製 Rounded M+</a><br><br>
<br>
Development for this plugin takes place at GitHub. To report bugs or feature requests, please use <a href="https://github.com/raspi0124/Japanese-font-for-TinyMCE">Github</a> issues.

== Installation ==
Same as other plugins.

== Frequently Asked Questions ==
Q ;The plugin does not work
A ;Please report it at github issue page.

== Changelog ==
Version beta-1 ;First release
